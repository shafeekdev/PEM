# Personal Expense Manager (Java Swing)

KTU S3 CSE - PBCST304 OOP using Java mini project.

## Run
    javac -encoding UTF-8 -d out $(find src -name '*.java')
    java -cp out Main
or open `src` in IntelliJ / Eclipse / NetBeans and run `Main`. The packaged `ExpenseTracker.jar` runs with `java -jar ExpenseTracker.jar`.

Create an account with "Create Account" (email + password), then login. Data is in memory only for now (JDBC/MySQL layer to be added).

## Packages
model, database (DataStore interface + InMemoryDataStore), service, gui, util
