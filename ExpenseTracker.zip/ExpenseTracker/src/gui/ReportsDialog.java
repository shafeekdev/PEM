package gui;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.YearMonth;
import javax.swing.*;
import service.*;
import util.*;

public class ReportsDialog extends JDialog {
    private final ExpenseService svc;
    private final JTextField month = new JTextField(YearMonth.now().toString(), 8);
    private final JComboBox<String> kind = new JComboBox<>(new String[]{"Monthly Summary", "Category-wise Report"});
    private final JTextField budget = new JTextField(8);
    private final JTextArea area = new JTextArea();
    private final Runnable onChange;

    public ReportsDialog(Frame owner, ExpenseService svc, Runnable onChange) {
        super(owner, "Reports", true);
        this.svc = svc;
        this.onChange = onChange;

        JButton show = new JButton("Show");
        show.addActionListener(e -> refresh());
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        top.add(new JLabel("Month (yyyy-MM):")); top.add(month);
        top.add(kind); top.add(show);

        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));

        JButton setBudget = new JButton("Set Budget");
        setBudget.addActionListener(e -> saveBudget());
        JButton copy = new JButton("Copy");
        copy.addActionListener(e -> Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new StringSelection(area.getText()), null));
        JButton print = new JButton("Print");
        print.addActionListener(e -> {
            try { area.print(); } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Could not print: " + ex.getMessage());
            }
        });
        JButton export = new JButton("Export");
        export.addActionListener(e -> export());
        JButton close = new JButton("Close");
        close.addActionListener(e -> dispose());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        bottom.add(new JLabel("Budget:")); bottom.add(budget); bottom.add(setBudget);
        bottom.add(copy); bottom.add(print); bottom.add(export); bottom.add(close);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(area), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        setSize(640, 460);
        setLocationRelativeTo(owner);
        refresh();
    }

    private YearMonth ym() {
        try { return YearMonth.parse(month.getText().trim()); }
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Month must be in yyyy-MM format, e.g. 2026-10.");
            return null;
        }
    }

    private Report current(YearMonth m) {
        return kind.getSelectedIndex() == 0 ? new MonthlyReport(svc, m) : new CategoryReport(svc, m);
    }

    private void refresh() {
        YearMonth m = ym();
        if (m == null) return;
        area.setText(current(m).generate());
        area.setCaretPosition(0);
    }

    private void saveBudget() {
        YearMonth m = ym();
        if (m == null) return;
        try {
            svc.setBudget(m, budget.getText());
            budget.setText("");
            refresh();
            onChange.run();
        } catch (InvalidInputException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void export() {
        YearMonth m = ym();
        if (m == null) return;
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("report-" + m + ".txt"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (Writer w = new OutputStreamWriter(new FileOutputStream(fc.getSelectedFile()), StandardCharsets.UTF_8)) {
            w.write(area.getText());
            JOptionPane.showMessageDialog(this, "Report saved.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save file: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
