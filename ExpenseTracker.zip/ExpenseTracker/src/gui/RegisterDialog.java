package gui;

import database.DataStore;
import java.awt.*;
import javax.swing.*;
import model.RegularUser;
import util.*;

public class RegisterDialog extends JDialog {
    private final DataStore store;
    private final JTextField name = new JTextField(18);
    private final JTextField email = new JTextField(18);
    private final JPasswordField pass = new JPasswordField(18);
    private final JPasswordField confirm = new JPasswordField(18);

    public RegisterDialog(Frame owner, DataStore store) {
        super(owner, "Create Account", true);
        this.store = store;

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 10, 8, 10);
        c.anchor = GridBagConstraints.WEST;
        String[] labels = {"Name:", "Email:", "Password:", "Confirm Password:"};
        JComponent[] fields = {name, email, pass, confirm};
        for (int i = 0; i < labels.length; i++) {
            c.gridx = 0; c.gridy = i; form.add(new JLabel(labels[i]), c);
            c.gridx = 1; form.add(fields[i], c);
        }

        JButton reg = new JButton("Register");
        JButton cancel = new JButton("Cancel");
        reg.addActionListener(e -> register());
        cancel.addActionListener(e -> dispose());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        buttons.add(reg);
        buttons.add(cancel);

        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(owner);
    }

    private void register() {
        try {
            String n = Validator.requireText(name.getText(), "Name");
            String e = Validator.requireEmail(email.getText());
            String p = new String(pass.getPassword());
            if (p.length() < 4) throw new InvalidInputException("Password must be at least 4 characters.");
            if (!p.equals(new String(confirm.getPassword())))
                throw new InvalidInputException("Passwords do not match.");
            if (store.findUser(e) != null)
                throw new InvalidInputException("An account with this email already exists.");
            store.addUser(new RegularUser(e, n, p));
            JOptionPane.showMessageDialog(this, "Account created. You can login now.");
            dispose();
        } catch (InvalidInputException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Create Account", JOptionPane.ERROR_MESSAGE);
        }
    }
}
