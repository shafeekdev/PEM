package gui;

import java.awt.*;
import java.time.LocalDate;
import javax.swing.*;
import model.Category;
import model.Transaction;
import service.ExpenseService;
import util.*;

/** Add / Edit dialog for income and expense entries. */
public class TransactionDialog extends JDialog {
    private final ExpenseService svc;
    private final String type;
    private final Transaction existing;
    private final JTextField date = new JTextField(20);
    private final JTextField amount = new JTextField(20);
    private final JComboBox<Category> category = new JComboBox<>();
    private final JTextField desc = new JTextField(20);
    private boolean saved = false;

    /** existing == null means a new entry of the given type. */
    public TransactionDialog(Frame owner, ExpenseService svc, String type, Transaction existing) {
        super(owner, (existing == null ? "Add " : "Edit ") + (type.equals(Constants.INCOME) ? "Income" : "Expense"), true);
        this.svc = svc;
        this.type = type;
        this.existing = existing;

        for (Category c : svc.categories(type)) category.addItem(c);

        if (existing == null) {
            date.setText(LocalDate.now().format(Constants.DATE_FMT));
        } else {
            date.setText(existing.getDate().format(Constants.DATE_FMT));
            amount.setText(String.valueOf(existing.getAmount()));
            desc.setText(existing.getDescription());
            for (int i = 0; i < category.getItemCount(); i++)
                if (category.getItemAt(i).getName().equals(existing.getCategory().getName()))
                    category.setSelectedIndex(i);
        }

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        String[] labels = {"Date (dd-MM-yyyy):", "Amount:", "Category:", "Description:"};
        JComponent[] fields = {date, amount, category, desc};
        for (int i = 0; i < labels.length; i++) {
            c.gridx = 0; c.gridy = i; c.weightx = 0; form.add(new JLabel(labels[i]), c);
            c.gridx = 1; c.weightx = 1; form.add(fields[i], c);
        }

        JButton cancel = new JButton("Cancel");
        JButton save = new JButton("Save");
        cancel.addActionListener(e -> dispose());
        save.addActionListener(e -> save());
        getRootPane().setDefaultButton(save);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        buttons.add(cancel);
        buttons.add(save);

        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        pack();
        setMinimumSize(new Dimension(420, getHeight()));
        setLocationRelativeTo(owner);
    }

    private void save() {
        try {
            Category c = (Category) category.getSelectedItem();
            if (existing == null)
                svc.addTransaction(type, c, amount.getText(), desc.getText(), date.getText());
            else
                svc.updateTransaction(existing, c, amount.getText(), desc.getText(), date.getText());
            saved = true;
            dispose();
        } catch (InvalidInputException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSaved() { return saved; }
}
