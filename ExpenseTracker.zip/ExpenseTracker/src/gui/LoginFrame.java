package gui;

import database.DataStore;
import java.awt.*;
import javax.swing.*;
import model.User;
import util.*;

public class LoginFrame extends JFrame {
    private final DataStore store;
    private final JTextField email = new JTextField(18);
    private final JPasswordField password = new JPasswordField(18);

    public LoginFrame(DataStore store) {
        super("Personal Expense Manager - Login");
        this.store = store;

        JLabel title = new JLabel("PERSONAL EXPENSE MANAGER", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0; c.gridy = 0; form.add(new JLabel("Email:"), c);
        c.gridx = 1; form.add(email, c);
        c.gridx = 0; c.gridy = 1; form.add(new JLabel("Password:"), c);
        c.gridx = 1; form.add(password, c);

        JButton login = new JButton("Login");
        JButton create = new JButton("Create Account");
        login.addActionListener(e -> doLogin());
        create.addActionListener(e -> new RegisterDialog(this, store).setVisible(true));
        getRootPane().setDefaultButton(login);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        buttons.add(login);
        buttons.add(create);

        setLayout(new BorderLayout(0, 10));
        add(title, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(20, 30, 15, 30));

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    private void doLogin() {
        try {
            String e = Validator.requireText(email.getText(), "Email");
            String p = Validator.requireText(new String(password.getPassword()), "Password");
            User u = store.findUser(e);
            if (u == null || !u.checkPassword(p))
                throw new InvalidInputException("Incorrect email or password.");
            dispose();
            new MainFrame(store, u).setVisible(true);
        } catch (InvalidInputException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Login", JOptionPane.ERROR_MESSAGE);
        }
    }
}
