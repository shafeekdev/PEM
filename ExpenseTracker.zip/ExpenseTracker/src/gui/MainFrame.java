package gui;

import database.DataStore;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import model.*;
import service.ExpenseService;
import util.*;

public class MainFrame extends JFrame {
    private final DataStore store;
    private final ExpenseService svc;
    private final JLabel income = new JLabel(), expense = new JLabel(), balance = new JLabel();
    private final JTextField search = new JTextField(12);
    private final JComboBox<String> typeBox = new JComboBox<>(new String[]{"All", "Income", "Expense"});
    private final JComboBox<String> catBox = new JComboBox<>();
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Date", "Type", "Category", "Amount", "Description"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);

    public MainFrame(DataStore store, User user) {
        super("Personal Expense Manager - " + user.getName());
        this.store = store;
        this.svc = new ExpenseService(store, user);

        JPanel cards = new JPanel(new GridLayout(1, 3, 15, 0));
        cards.add(card("TOTAL INCOME", income));
        cards.add(card("TOTAL EXPENSE", expense));
        cards.add(card("BALANCE", balance));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        JButton addInc = new JButton("+ Add Income");
        JButton addExp = new JButton("+ Add Expense");
        JButton edit = new JButton("Edit");
        JButton del = new JButton("Delete");
        JButton reports = new JButton("Reports");
        JButton cats = new JButton("Categories");
        JButton logout = new JButton("Logout");
        for (JButton b : new JButton[]{addInc, addExp, edit, del, reports, cats, logout}) buttons.add(b);
        addInc.addActionListener(e -> add(Constants.INCOME));
        addExp.addActionListener(e -> add(Constants.EXPENSE));
        edit.addActionListener(e -> editSelected());
        del.addActionListener(e -> deleteSelected());
        reports.addActionListener(e -> new ReportsDialog(this, svc, this::refresh).setVisible(true));
        cats.addActionListener(e -> { new CategoriesDialog(this, svc).setVisible(true); loadCategoryFilter(); });
        logout.addActionListener(e -> { dispose(); new LoginFrame(store).setVisible(true); });

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        JButton apply = new JButton("Apply");
        JButton clear = new JButton("Clear");
        filters.add(new JLabel("Search:")); filters.add(search);
        filters.add(new JLabel("Type:")); filters.add(typeBox);
        filters.add(new JLabel("Category:")); filters.add(catBox);
        filters.add(apply); filters.add(clear);
        apply.addActionListener(e -> refresh());
        search.addActionListener(e -> refresh());
        clear.addActionListener(e -> {
            search.setText(""); typeBox.setSelectedIndex(0); catBox.setSelectedIndex(0); refresh();
        });

        JPanel north = new JPanel(new GridLayout(3, 1, 0, 15));
        north.setBorder(new EmptyBorder(15, 15, 10, 15));
        north.add(cards);
        north.add(buttons);
        north.add(filters);

        table.getColumnModel().getColumn(0).setMaxWidth(60);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane sp = new JScrollPane(table);
        JPanel center = new JPanel(new BorderLayout());
        center.setBorder(new EmptyBorder(0, 15, 15, 15));
        center.add(sp, BorderLayout.CENTER);

        add(north, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        loadCategoryFilter();
        refresh();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
    }

    private JPanel card(String title, JLabel value) {
        JPanel p = new JPanel(new GridLayout(2, 1, 0, 6));
        p.setBorder(new CompoundBorder(new LineBorder(Color.GRAY), new EmptyBorder(12, 14, 12, 14)));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Arial", Font.BOLD, 14));
        value.setFont(new Font("Arial", Font.BOLD, 24));
        p.add(t);
        p.add(value);
        return p;
    }

    private void loadCategoryFilter() {
        Object sel = catBox.getSelectedItem();
        catBox.removeAllItems();
        catBox.addItem("All");
        for (String n : svc.allCategoryNames()) catBox.addItem(n);
        if (sel != null) catBox.setSelectedItem(sel);
    }

    private void add(String type) {
        TransactionDialog d = new TransactionDialog(this, svc, type, null);
        d.setVisible(true);
        if (d.isSaved()) refresh();
    }

    private Transaction selected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a transaction first.");
            return null;
        }
        return svc.findById((Integer) model.getValueAt(row, 0));
    }

    private void editSelected() {
        Transaction t = selected();
        if (t == null) return;
        TransactionDialog d = new TransactionDialog(this, svc, t.getType(), t);
        d.setVisible(true);
        if (d.isSaved()) refresh();
    }

    private void deleteSelected() {
        Transaction t = selected();
        if (t == null) return;
        int r = JOptionPane.showConfirmDialog(this, "Delete this transaction?",
                "Confirm", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            svc.deleteTransaction(t.getId());
            refresh();
        }
    }

    private void refresh() {
        double i = svc.totalAll(Constants.INCOME), e = svc.totalAll(Constants.EXPENSE);
        income.setText(Constants.money(i));
        expense.setText(Constants.money(e));
        balance.setText(Constants.money(i - e));

        String ty = typeBox.getSelectedIndex() == 0 ? null
                : typeBox.getSelectedIndex() == 1 ? Constants.INCOME : Constants.EXPENSE;
        String cat = catBox.getSelectedIndex() <= 0 ? null : (String) catBox.getSelectedItem();
        List<Transaction> list = svc.search(search.getText(), ty, cat, (LocalDate) null, (LocalDate) null);
        model.setRowCount(0);
        for (Transaction t : list)
            model.addRow(new Object[]{t.getId(), t.getDate().format(Constants.DATE_FMT),
                    t.getType().equals(Constants.INCOME) ? "Income" : "Expense",
                    t.getCategory().getName(), Constants.money(t.getAmount()), t.getDescription()});
    }
}
