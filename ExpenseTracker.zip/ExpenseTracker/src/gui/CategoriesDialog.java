package gui;

import java.awt.*;
import javax.swing.*;
import model.Category;
import service.ExpenseService;
import util.*;

public class CategoriesDialog extends JDialog {
    private final ExpenseService svc;
    private final DefaultListModel<String> model = new DefaultListModel<>();
    private final JTextField name = new JTextField(14);
    private final JComboBox<String> type = new JComboBox<>(new String[]{"Income", "Expense"});

    public CategoriesDialog(Frame owner, ExpenseService svc) {
        super(owner, "Categories", true);
        this.svc = svc;
        load();

        JPanel add = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        JButton addBtn = new JButton("Add");
        addBtn.addActionListener(e -> addCategory());
        add.add(new JLabel("Name:")); add.add(name);
        add.add(type); add.add(addBtn);

        JButton close = new JButton("Close");
        close.addActionListener(e -> dispose());
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        bottom.add(close);

        add(new JScrollPane(new JList<>(model)), BorderLayout.CENTER);
        add(add, BorderLayout.NORTH);
        add(bottom, BorderLayout.SOUTH);
        setSize(420, 360);
        setLocationRelativeTo(owner);
    }

    private void load() {
        model.clear();
        for (Category c : svc.categories(Constants.INCOME)) model.addElement("Income  -  " + c.getName());
        for (Category c : svc.categories(Constants.EXPENSE)) model.addElement("Expense  -  " + c.getName());
    }

    private void addCategory() {
        try {
            String t = type.getSelectedIndex() == 0 ? Constants.INCOME : Constants.EXPENSE;
            svc.addCategory(name.getText(), t);
            name.setText("");
            load();
        } catch (InvalidInputException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
