package model;

public class Admin extends User {
    public Admin(String username, String name, String password) {
        super(username, name, password);
    }
    @Override public String getRole() { return "Admin"; }
}
