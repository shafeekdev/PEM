package model;

/** Abstract base for all users (Inheritance + Abstraction). */
public abstract class User {
    private final String username;
    private String name;
    private final String password;

    protected User(String username, String name, String password) {
        this.username = username;
        this.name = name;
        this.password = password;
    }

    public String getUsername() { return username; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public boolean checkPassword(String p) { return password.equals(p); }

    /** Polymorphic: each subclass reports its own role. */
    public abstract String getRole();
}
