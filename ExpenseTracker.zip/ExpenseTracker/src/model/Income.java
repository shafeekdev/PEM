package model;

import java.time.LocalDate;
import util.Constants;

public class Income extends Transaction {
    public Income(String u, Category c, double a, String d, LocalDate date) {
        super(u, c, a, d, date);
    }
    @Override public String getType() { return Constants.INCOME; }
}
