package model;

import java.time.LocalDate;
import util.Constants;

public class Expense extends Transaction {
    public Expense(String u, Category c, double a, String d, LocalDate date) {
        super(u, c, a, d, date);
    }
    @Override public String getType() { return Constants.EXPENSE; }
}
