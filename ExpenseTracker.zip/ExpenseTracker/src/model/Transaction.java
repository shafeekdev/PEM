package model;

import java.time.LocalDate;

/** Abstract parent of Income and Expense. */
public abstract class Transaction {
    private int id;
    private final String username;
    private Category category;
    private double amount;
    private String description;
    private LocalDate date;

    protected Transaction(String username, Category category, double amount,
                          String description, LocalDate date) {
        this.username = username;
        this.category = category;
        this.amount = amount;
        this.description = description;
        this.date = date;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getUsername() { return username; }
    public Category getCategory() { return category; }
    public void setCategory(Category c) { this.category = c; }
    public double getAmount() { return amount; }
    public void setAmount(double a) { this.amount = a; }
    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate d) { this.date = d; }

    public abstract String getType();
}
