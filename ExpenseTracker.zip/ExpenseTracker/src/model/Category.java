package model;

public class Category {
    private final String name;
    private final String type; // INCOME or EXPENSE

    public Category(String name, String type) {
        this.name = name;
        this.type = type;
    }
    public String getName() { return name; }
    public String getType() { return type; }
    @Override public String toString() { return name; }
}
