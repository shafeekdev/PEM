package model;

public class RegularUser extends User {
    public RegularUser(String username, String name, String password) {
        super(username, name, password);
    }
    @Override public String getRole() { return "User"; }
}
