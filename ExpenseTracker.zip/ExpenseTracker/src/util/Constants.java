package util;

import java.time.format.DateTimeFormatter;

public final class Constants {
    private Constants() {}
    public static final String INCOME = "INCOME";
    public static final String EXPENSE = "EXPENSE";
    public static final String RUPEE = "\u20B9";
    public static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public static String money(double v) {
        return String.format("%s%,.2f", RUPEE, v);
    }
}
