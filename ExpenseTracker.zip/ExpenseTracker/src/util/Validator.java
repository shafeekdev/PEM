package util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public final class Validator {
    private Validator() {}

    public static String requireText(String s, String field) throws InvalidInputException {
        if (s == null || s.trim().isEmpty())
            throw new InvalidInputException(field + " cannot be empty.");
        return s.trim();
    }

    public static double parseAmount(String s) throws InvalidInputException {
        requireText(s, "Amount");
        try {
            double v = Double.parseDouble(s.trim());
            if (v <= 0) throw new InvalidInputException("Amount must be greater than zero.");
            return v;
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Amount must be a valid number.");
        }
    }

    public static LocalDate parseDate(String s) throws InvalidInputException {
        requireText(s, "Date");
        try {
            return LocalDate.parse(s.trim(), Constants.DATE_FMT);
        } catch (DateTimeParseException e) {
            throw new InvalidInputException("Date must be in dd-MM-yyyy format.");
        }
    }

    public static String requireEmail(String s) throws InvalidInputException {
        s = requireText(s, "Email");
        if (!s.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))
            throw new InvalidInputException("Please enter a valid email address.");
        return s;
    }
}
