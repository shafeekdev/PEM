package database;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import model.*;
import util.Constants;

/** Temporary storage so the front-end works before JDBC is added. */
public class InMemoryDataStore implements DataStore {
    private final Map<String, User> users = new HashMap<>();
    private final Map<String, List<Category>> categories = new HashMap<>();
    private final List<Transaction> transactions = new ArrayList<>();
    private final Map<String, Double> budgets = new HashMap<>();
    private int nextId = 1;

    public InMemoryDataStore() {
        seedDemo();
    }

    @Override public User findUser(String username) { return users.get(username.toLowerCase()); }

    @Override public void addUser(User user) {
        users.put(user.getUsername().toLowerCase(), user);
        List<Category> defaults = new ArrayList<>();
        for (String n : new String[]{"Salary", "Pocket Money", "Scholarship", "Other Income"})
            defaults.add(new Category(n, Constants.INCOME));
        for (String n : new String[]{"Food", "Travel", "Education", "Entertainment", "Shopping", "Bills", "Other"})
            defaults.add(new Category(n, Constants.EXPENSE));
        categories.put(user.getUsername().toLowerCase(), defaults);
    }

    @Override public List<Category> getCategories(String u) {
        return categories.getOrDefault(u.toLowerCase(), new ArrayList<>());
    }

    @Override public void addCategory(String u, Category c) {
        categories.computeIfAbsent(u.toLowerCase(), k -> new ArrayList<>()).add(c);
    }

    @Override public List<Transaction> getTransactions(String u) {
        List<Transaction> out = new ArrayList<>();
        for (Transaction t : transactions)
            if (t.getUsername().equalsIgnoreCase(u)) out.add(t);
        return out;
    }

    @Override public void saveTransaction(Transaction t) {
        if (t.getId() == 0) {
            t.setId(nextId++);
            transactions.add(t);
        }
        // existing objects are already updated in place
    }

    @Override public void deleteTransaction(int id) {
        transactions.removeIf(t -> t.getId() == id);
    }

    private String key(String u, YearMonth m) { return u.toLowerCase() + "|" + m; }

    @Override public Double getBudget(String u, YearMonth m) { return budgets.get(key(u, m)); }
    @Override public void saveBudget(String u, YearMonth m, double a) { budgets.put(key(u, m), a); }

    private void seedDemo() {
        addUser(new Admin("admin", "Administrator", "admin"));
        addUser(new RegularUser("demo", "Demo Student", "demo"));
    }
}
