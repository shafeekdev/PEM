package database;

import java.time.YearMonth;
import java.util.List;
import model.*;

/**
 * Storage contract. The GUI/service layers depend only on this interface,
 * so a JDBC/MySQL implementation can replace InMemoryDataStore later.
 */
public interface DataStore {
    User findUser(String username);
    void addUser(User user);

    List<Category> getCategories(String username);
    void addCategory(String username, Category category);

    List<Transaction> getTransactions(String username);
    void saveTransaction(Transaction t);   // insert (id == 0) or update
    void deleteTransaction(int id);

    Double getBudget(String username, YearMonth month); // null if not set
    void saveBudget(String username, YearMonth month, double amount);
}
