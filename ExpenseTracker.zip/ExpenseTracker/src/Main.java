import database.DataStore;
import database.InMemoryDataStore;
import gui.LoginFrame;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) { }
        SwingUtilities.invokeLater(() -> {
            DataStore store = new InMemoryDataStore(); // swap for a JDBC store later
            new LoginFrame(store).setVisible(true);
        });
    }
}
