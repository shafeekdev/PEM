package service;

import database.DataStore;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;
import model.*;
import util.*;

/** Business logic: validation, totals, search, budgets. */
public class ExpenseService {
    private final DataStore store;
    private final User user;

    public ExpenseService(DataStore store, User user) {
        this.store = store;
        this.user = user;
    }

    public User getUser() { return user; }

    public List<Category> categories(String type) {
        return store.getCategories(user.getUsername()).stream()
                .filter(c -> c.getType().equals(type)).collect(Collectors.toList());
    }

    public Category addCategory(String name, String type) throws InvalidInputException {
        name = Validator.requireText(name, "Category name");
        for (Category c : categories(type))
            if (c.getName().equalsIgnoreCase(name))
                throw new InvalidInputException("Category already exists.");
        Category c = new Category(name, type);
        store.addCategory(user.getUsername(), c);
        return c;
    }

    public Transaction addTransaction(String type, Category cat, String amount,
                                      String desc, String date) throws InvalidInputException {
        if (cat == null) throw new InvalidInputException("Please select a category.");
        double a = Validator.parseAmount(amount);
        LocalDate d = Validator.parseDate(date);
        String ds = desc == null ? "" : desc.trim();
        Transaction t = type.equals(Constants.INCOME)
                ? new Income(user.getUsername(), cat, a, ds, d)
                : new Expense(user.getUsername(), cat, a, ds, d);
        store.saveTransaction(t);
        return t;
    }

    public void updateTransaction(Transaction t, Category cat, String amount,
                                  String desc, String date) throws InvalidInputException {
        if (cat == null) throw new InvalidInputException("Please select a category.");
        double a = Validator.parseAmount(amount);
        LocalDate d = Validator.parseDate(date);
        t.setCategory(cat);
        t.setAmount(a);
        t.setDescription(desc == null ? "" : desc.trim());
        t.setDate(d);
        store.saveTransaction(t);
    }

    public void deleteTransaction(int id) { store.deleteTransaction(id); }

    public Transaction findById(int id) {
        for (Transaction t : store.getTransactions(user.getUsername()))
            if (t.getId() == id) return t;
        return null;
    }

    /** Search/filter. Any argument may be null/empty to skip that filter. */
    public List<Transaction> search(String text, String type, LocalDate from, LocalDate to) {
        String q = text == null ? "" : text.trim().toLowerCase();
        return store.getTransactions(user.getUsername()).stream()
                .filter(t -> type == null || t.getType().equals(type))
                .filter(t -> from == null || !t.getDate().isBefore(from))
                .filter(t -> to == null || !t.getDate().isAfter(to))
                .filter(t -> q.isEmpty()
                        || t.getDescription().toLowerCase().contains(q)
                        || t.getCategory().getName().toLowerCase().contains(q))
                .sorted(Comparator.comparing(Transaction::getDate).reversed()
                        .thenComparing(Comparator.comparingInt(Transaction::getId).reversed()))
                .collect(Collectors.toList());
    }

    /** Same as search() with an extra category-name filter (null = all categories). */
    public List<Transaction> search(String text, String type, String category,
                                    LocalDate from, LocalDate to) {
        return search(text, type, from, to).stream()
                .filter(t -> category == null || t.getCategory().getName().equals(category))
                .collect(Collectors.toList());
    }

    public double totalAll(String type) {
        return store.getTransactions(user.getUsername()).stream()
                .filter(t -> t.getType().equals(type))
                .mapToDouble(Transaction::getAmount).sum();
    }

    public List<String> allCategoryNames() {
        return store.getCategories(user.getUsername()).stream()
                .map(Category::getName).distinct().sorted().collect(Collectors.toList());
    }

    public List<Transaction> forMonth(YearMonth ym) {
        return search(null, null, ym.atDay(1), ym.atEndOfMonth());
    }

    public double total(YearMonth ym, String type) {
        return forMonth(ym).stream().filter(t -> t.getType().equals(type))
                .mapToDouble(Transaction::getAmount).sum();
    }

    public double balance(YearMonth ym) {
        return total(ym, Constants.INCOME) - total(ym, Constants.EXPENSE);
    }

    public Map<String, Double> categoryTotals(YearMonth ym, String type) {
        Map<String, Double> m = new TreeMap<>();
        for (Transaction t : forMonth(ym))
            if (t.getType().equals(type))
                m.merge(t.getCategory().getName(), t.getAmount(), Double::sum);
        return m;
    }

    public Double getBudget(YearMonth ym) { return store.getBudget(user.getUsername(), ym); }

    public void setBudget(YearMonth ym, String amount) throws InvalidInputException {
        store.saveBudget(user.getUsername(), ym, Validator.parseAmount(amount));
    }
}
