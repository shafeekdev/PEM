package service;

import java.time.YearMonth;
import java.util.Map;
import util.Constants;

public class CategoryReport implements Report {
    private final ExpenseService svc;
    private final YearMonth ym;

    public CategoryReport(ExpenseService svc, YearMonth ym) { this.svc = svc; this.ym = ym; }

    @Override public String getTitle() { return "Category-wise Report"; }

    @Override public String generate() {
        StringBuilder sb = new StringBuilder("Category-wise spending for " + ym + "\n\n");
        Map<String, Double> m = svc.categoryTotals(ym, Constants.EXPENSE);
        double total = svc.total(ym, Constants.EXPENSE);
        if (m.isEmpty()) return sb.append("No expenses recorded.").toString();
        m.forEach((k, v) -> sb.append(String.format("%-18s %12s %6.1f%%%n",
                k, Constants.money(v), total == 0 ? 0 : v / total * 100)));
        sb.append("-".repeat(38)).append('\n');
        sb.append(String.format("%-18s %12s%n", "Total", Constants.money(total)));
        return sb.toString();
    }
}
