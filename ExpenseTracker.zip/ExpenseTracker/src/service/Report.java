package service;

/** Common contract for all reports (Interface + Polymorphism). */
public interface Report {
    String getTitle();
    String generate();
}
