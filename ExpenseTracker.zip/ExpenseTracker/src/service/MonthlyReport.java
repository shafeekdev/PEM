package service;

import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;
import util.Constants;

public class MonthlyReport implements Report {
    private final ExpenseService svc;
    private final YearMonth ym;

    public MonthlyReport(ExpenseService svc, YearMonth ym) { this.svc = svc; this.ym = ym; }

    @Override public String getTitle() { return "Monthly Summary"; }

    @Override public String generate() {
        StringBuilder sb = new StringBuilder();
        sb.append(ym.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH))
          .append(' ').append(ym.getYear()).append("\n\n");
        sb.append(String.format("%-18s %14s%n", "Income", Constants.money(svc.total(ym, Constants.INCOME))));
        svc.categoryTotals(ym, Constants.EXPENSE).forEach((k, v) ->
                sb.append(String.format("%-18s %14s%n", k, Constants.money(v))));
        sb.append("-".repeat(33)).append('\n');
        double spent = svc.total(ym, Constants.EXPENSE);
        sb.append(String.format("%-18s %14s%n", "Total Expenses", Constants.money(spent)));
        sb.append(String.format("%-18s %14s%n", "Balance", Constants.money(svc.balance(ym))));
        Double b = svc.getBudget(ym);
        if (b != null) {
            sb.append(String.format("%n%-18s %14s%n", "Budget", Constants.money(b)));
            sb.append(String.format("%-18s %13.1f%%%n", "Budget used", spent / b * 100));
        }
        return sb.toString();
    }
}
